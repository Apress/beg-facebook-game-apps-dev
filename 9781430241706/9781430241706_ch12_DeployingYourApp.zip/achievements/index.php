<?php

require_once('../libs/db_manager.php');

?>
<!doctype html>
<html lang="en">
<head>
<title><?php echo $achivement['title']; ?></title>
<meta property="og:type" content="game.achievement">
<meta property="og:url" content="">
<meta property="og:title" content="<?php echo $achievement['title']; ?>">
<meta property="og:description" content="<?php echo $achievement['description']; ?>">
<meta property="og:image" content="<?php echo $achievement['image']; ?>">
<meta property="game:points" content="<?php echo $achievement['points']; ?>">
<meta property="fb:app_id" content="app_id">
</head>
<body>
<?php echo $achievement['description']; ?>
</body>
</html>
