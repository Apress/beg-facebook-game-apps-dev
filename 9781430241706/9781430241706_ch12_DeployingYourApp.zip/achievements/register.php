<?php

require_once('../libs/db_manager.php');
require_once('../FBUtils.php');
require_once('../AppInfo.php');
require_once('../utils.php');


$db = new DB_Manager();

$achievements_query = $db->query('SELECT * FROM achievements;');

//$token = FBUtils::login();
$app_id = AppInfo::appID();
$app_info = FBUtils::fetchFromFBGraph("$app_id");
$app_secret = AppInfo::appSecret();


$sql = <<<SQL
SELECT * FROM achievements;
SQL;

$db = new DB_Manager();
$results = pg_fetch_array($db->query($sql));



$achivement_stub = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];


session_start();
  if(isset($_REQUEST["code"])) {
     $code = $_REQUEST["code"];
  }

  if(empty($code) && !isset($_REQUEST['error'])) {
    $_SESSION['state'] = md5(uniqid(rand(), TRUE)); //CSRF protection
    $dialog_url = 'https://www.facebook.com/dialog/oauth?' 
      . 'client_id=' . $app_id
      . '&redirect_uri=' . urlencode($canvas_page_url)
      . '&state=' . $_SESSION['state']
      . '&scope=publish_actions';

    print('<script> top.location.href=\'' . $dialog_url . '\'</script>');
    exit;
  } else if(isset($_REQUEST['error'])) { 
    // The user did not authorize the app
    print($_REQUEST['error_description']);
    exit;
  }


print_r($token);
