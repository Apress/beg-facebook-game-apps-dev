<?php
  echo('<body onload="window.close();" />');
?>
